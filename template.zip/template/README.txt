Inicialmente digitar no terminal (isso instala as bibliotecas)
    pip install -r requirements.txt

Em seguida basta digital no terminal para iniciar o servidor
    python server.py

Ao clicar na url que aparece a pagina já será exibida

